create view USER_NAME as
  SELECT "user_name"
FROM "temp_user_table"
/

